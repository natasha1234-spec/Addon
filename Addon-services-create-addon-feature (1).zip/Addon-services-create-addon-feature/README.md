# Spring Boot Application

This README provides an overview of a Spring Boot application and guides you through the necessary steps to set up a connection to a MySQL database. Additionally, some template text for potential output is included.

## Prerequisites

Before you start, make sure you have:
- JDK 17 or later installed.
- Maven installed.
- MySQL Server installed and running.

## Setup Instructions

### 1. Clone the Repository
```bash
git clone <repository-url>
cd <repository-name>
```

### 2. Update the `application.properties` File

To connect your Spring Boot application to a MySQL database, you need to configure the `application.properties` file located in the `src/main/resources` directory. Add or update the following properties:

```properties
# MySQL Database Connection
spring.datasource.url=jdbc:mysql://<host>:<port>/<database_name>
spring.datasource.username=<your_username>
spring.datasource.password=<your_password>
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# Hibernate Configuration
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect

# Server Port (optional)
server.port=8080
```

Replace:
- `<host>` with your database host (e.g., `localhost`).
- `<port>` with your MySQL server port (default is `3306`).
- `<database_name>` with the name of your MySQL database.
- `<your_username>` with your MySQL username.
- `<your_password>` with your MySQL password.

### 3. Build and Run the Application

Using Maven:
```bash
mvn clean install
mvn spring-boot:run
```



### Create addon services Output :
![image](https://github.com/user-attachments/assets/8f240c35-b030-489c-8fc5-18d9f93508c0)
# Image Description: Quick Park Assist - Addon Services

The provided image displays a user interface for the **Quick Park Assist** application, specifically the **Addon Services** section. Key features include:

1. **Sidebar Navigation**:
   - The left sidebar contains options for managing addon services:
     - Create a new addon pack.
     - Modify addon details.
     - View all addon offers.
     - View addons for a vehicle.
     - Remove an addon pack.

2. **Addon Creation Form**:
   - The main section shows a form titled **Create Addon Services** with the following fields:
     - **Name**: Input for the name of the addon service.
     - **Description**: Text field for describing the addon.
     - **Duration**: Numeric input for specifying the service duration.
     - **Price**: Numeric input for the price of the addon.
   - A **Save** button is present to submit the form.

3. **Background**:
   - The background features an image of a car parking system, emphasizing the application's theme of parking management.

4. **Top Navigation Bar**:
   - The top menu includes options such as:
     - Home
     - Registration
     - Smart Spots
     - Booking
     - Addon Services
     - EV Charging
     - A search icon.

This interface is part of a parking management system, allowing users to manage additional services related to parking.

#### Console Logs
```plaintext
 :: Spring Boot ::                (v3.4.0)
2024-12-20T16:58:58.771+05:30  INFO 14720 --- [module] [  restartedMain] com.module.module.ModuleApplication      : Starting ModuleApplication using Java 17.0.12 with PID 14720 (C:\Users\vedan\Downloads\module\target\classes started by vedan in C:\Users\vedan\Downloads\module)
2024-12-20T16:58:58.778+05:30  INFO 14720 --- [module] [  restartedMain] com.module.module.ModuleApplication      : No active profile set, falling back to 1 default profile: "default"
2024-12-20T16:58:58.903+05:30  INFO 14720 --- [module] [  restartedMain] .e.DevToolsPropertyDefaultsPostProcessor : Devtools property defaults active! Set 'spring.devtools.add-properties' to 'false' to disable
2024-12-20T16:58:58.904+05:30  INFO 14720 --- [module] [  restartedMain] .e.DevToolsPropertyDefaultsPostProcessor : For additional web related logging consider setting the 'logging.level.web' property to 'DEBUG'
2024-12-20T16:59:00.628+05:30  INFO 14720 --- [module] [  restartedMain] .s.d.r.c.RepositoryConfigurationDelegate : Bootstrapping Spring Data JPA repositories in DEFAULT mode.
2024-12-20T16:59:00.889+05:30  INFO 14720 --- [module] [  restartedMain] .s.d.r.c.RepositoryConfigurationDelegate : Finished Spring Data repository scanning in 215 ms. Found 1 JPA repository interface.
2024-12-20T16:59:02.242+05:30  INFO 14720 --- [module] [  restartedMain] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized with port 8080 (http)
2024-12-20T16:59:02.273+05:30  INFO 14720 --- [module] [  restartedMain] o.apache.catalina.core.StandardService   : Starting service [Tomcat]
2024-12-20T16:59:02.274+05:30  INFO 14720 --- [module] [  restartedMain] o.apache.catalina.core.StandardEngine    : Starting Servlet engine: [Apache Tomcat/10.1.33]
2024-12-20T16:59:02.339+05:30  INFO 14720 --- [module] [  restartedMain] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
2024-12-20T16:59:02.341+05:30  INFO 14720 --- [module] [  restartedMain] w.s.c.ServletWebServerApplicationContext : Root WebApplicationContext: initialization completed in 3433 ms
2024-12-20T16:59:02.617+05:30  INFO 14720 --- [module] [  restartedMain] o.hibernate.jpa.internal.util.LogHelper  : HHH000204: Processing PersistenceUnitInfo [name: default]
2024-12-20T16:59:02.723+05:30  INFO 14720 --- [module] [  restartedMain] org.hibernate.Version                    : HHH000412: Hibernate ORM core version 6.6.2.Final
2024-12-20T16:59:02.779+05:30  INFO 14720 --- [module] [  restartedMain] o.h.c.internal.RegionFactoryInitiator    : HHH000026: Second-level cache disabled
2024-12-20T16:59:03.544+05:30  INFO 14720 --- [module] [  restartedMain] o.s.o.j.p.SpringPersistenceUnitInfo      : No LoadTimeWeaver setup: ignoring JPA class transformer
2024-12-20T16:59:03.661+05:30  INFO 14720 --- [module] [  restartedMain] com.zaxxer.hikari.HikariDataSource       : HikariPool-1 - Starting...
2024-12-20T16:59:04.413+05:30  INFO 14720 --- [module] [  restartedMain] com.zaxxer.hikari.pool.HikariPool        : HikariPool-1 - Added connection com.mysql.cj.jdbc.ConnectionImpl@5f9e5e80
2024-12-20T16:59:04.416+05:30  INFO 14720 --- [module] [  restartedMain] com.zaxxer.hikari.HikariDataSource       : HikariPool-1 - Start completed.  
2024-12-20T16:59:04.559+05:30  INFO 14720 --- [module] [  restartedMain] org.hibernate.orm.connections.pooling    : HHH10001005: Database info:
        Database JDBC URL [Connecting through datasource 'HikariDataSource (HikariPool-1)']
        Database driver: undefined/unknown
        Database version: 8.0.40
        Autocommit mode: undefined/unknown
        Isolation level: undefined/unknown
        Minimum pool size: undefined/unknown
        Maximum pool size: undefined/unknown
2024-12-20T16:59:05.778+05:30  INFO 14720 --- [module] [  restartedMain] o.h.e.t.j.p.i.JtaPlatformInitiator       : HHH000489: No JTA platform available (set 'hibernate.transaction.jta.platform' to enable JTA platform integration)
2024-12-20T16:59:05.833+05:30  INFO 14720 --- [module] [  restartedMain] j.LocalContainerEntityManagerFactoryBean : Initialized JPA EntityManagerFactory for persistence unit 'default'
2024-12-20T16:59:06.529+05:30  WARN 14720 --- [module] [  restartedMain] JpaBaseConfiguration$JpaWebConfiguration : spring.jpa.open-in-view is enabled by default. Therefore, database queries may be performed during view rendering. Explicitly configure spring.jpa.open-in-view to disable this warning
2024-12-20T16:59:06.602+05:30  INFO 14720 --- [module] [  restartedMain] o.s.b.a.w.s.WelcomePageHandlerMapping    : Adding welcome page template: index
2024-12-20T16:59:07.513+05:30  INFO 14720 --- [module] [  restartedMain] o.s.b.d.a.OptionalLiveReloadServer       : LiveReload server is running on port 35729
2024-12-20T16:59:07.635+05:30  INFO 14720 --- [module] [  restartedMain] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port 8080 (http) with context path '/'
2024-12-20T16:59:07.667+05:30  INFO 14720 --- [module] [  restartedMain] com.module.module.ModuleApplication      : Started ModuleApplication in 9.593 seconds (process running for 10.224)
2024-12-20T16:59:12.964+05:30  INFO 14720 --- [module] [nio-8080-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring DispatcherServlet 'dispatcherServlet'
2024-12-20T16:59:12.964+05:30  INFO 14720 --- [module] [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'
2024-12-20T16:59:12.966+05:30  INFO 14720 --- [module] [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Completed initialization in 1 ms 
```

