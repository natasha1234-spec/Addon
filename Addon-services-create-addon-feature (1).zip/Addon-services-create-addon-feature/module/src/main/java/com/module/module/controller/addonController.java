package com.module.module.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.module.module.entity.addon;
import com.module.module.repository.addonRepository;

@Controller
public class addonController {
    @Autowired
    private addonRepository eRepo;

    @GetMapping({"/addAddonServices", "/"})
    public String addAddonServices(Model model) {
        addon newAddon = new addon();
        model.addAttribute("addon", newAddon);
        return "index";
    }

    @PostMapping("/saveAddonServices")
    public String createAddonServices(@ModelAttribute addon newAddon) {
        eRepo.save(newAddon);
        return "redirect:/viewAllAddonServices";
    }

    @GetMapping("/viewAllAddonServices")
    public String viewAllAddonServices(Model model) {
        model.addAttribute("addonServices", eRepo.findAll());
        return "view-all-addon-services";
    }
}