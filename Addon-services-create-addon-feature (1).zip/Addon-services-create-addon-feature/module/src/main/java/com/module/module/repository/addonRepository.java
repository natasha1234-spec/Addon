package com.module.module.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.module.module.entity.addon;

@Repository
public interface addonRepository extends JpaRepository<addon, Long> {
}